#ifndef TIMER_H
#define TIMER_H
#include <avr/io.h>

void timer_init(void);
uint32_t millis(void);

#endif