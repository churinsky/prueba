#include "nivel.h"

void nivel_init(Nivel *nivel)
{
    *(nivel->ddr)&=~(1<<nivel->pin);//configuraciona comoentrada
    *(nivel->port)|=(1<<nivel->pin);// pullup
}
bool nivel_read(Nivel *nivel)
{
    return !(*(nivel->pin_reg)&(1<<nivel->pin));//activacionen bajpo
}